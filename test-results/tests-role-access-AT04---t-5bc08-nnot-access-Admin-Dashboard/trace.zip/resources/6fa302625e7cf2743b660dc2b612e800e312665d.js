(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/_workflow/JobBoard.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>JobBoard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$useWorkflow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/_workflow/useWorkflow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$display$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/_workflow/display.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$Shared$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/_workflow/Shared.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/app/_workflow/workflow.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function JobBoard({ completed = false }) {
    _s();
    const state = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$useWorkflow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('technician');
    const { data, refresh } = state;
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const jobs = data ? completed ? data.completed : data.assigned : [];
    const visibleJobs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$display$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterReports"])(jobs, search);
    const notificationsLink = data ? `/technician/notifications?userId=${data.user.id}` : '/technician/notifications';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].page,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$Shared$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageHeader"], {
                role: "Technician",
                title: completed ? 'Completed jobs' : 'Assigned jobs',
                subtitle: completed ? 'A record of the maintenance jobs you have finished.' : 'View your current jobs and open notifications to update their progress.',
                refresh: refresh
            }, void 0, false, {
                fileName: "[project]/app/_workflow/JobBoard.js",
                lineNumber: 19,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].tabs,
                "aria-label": "Technician jobs",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/technician/assigned",
                        "aria-current": !completed ? 'page' : undefined,
                        children: [
                            "Assigned jobs",
                            data ? ` (${data.assigned.length})` : ''
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/_workflow/JobBoard.js",
                        lineNumber: 23,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/technician/completed",
                        "aria-current": completed ? 'page' : undefined,
                        children: [
                            "Completed jobs",
                            data ? ` (${data.completed.length})` : ''
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/_workflow/JobBoard.js",
                        lineNumber: 24,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: notificationsLink,
                        children: "Notifications"
                    }, void 0, false, {
                        fileName: "[project]/app/_workflow/JobBoard.js",
                        lineNumber: 25,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/_workflow/JobBoard.js",
                lineNumber: 22,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$Shared$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LoadState"], {
                ...state
            }, void 0, false, {
                fileName: "[project]/app/_workflow/JobBoard.js",
                lineNumber: 27,
                columnNumber: 5
            }, this),
            data && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    !data.technician && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].error,
                        role: "alert",
                        children: "Your technician profile has not been set up. Please contact maintenance."
                    }, void 0, false, {
                        fileName: "[project]/app/_workflow/JobBoard.js",
                        lineNumber: 29,
                        columnNumber: 28
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].filters,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                children: [
                                    "Search jobs",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        value: search,
                                        onChange: (e)=>setSearch(e.target.value),
                                        placeholder: "Report number, location or description"
                                    }, void 0, false, {
                                        fileName: "[project]/app/_workflow/JobBoard.js",
                                        lineNumber: 30,
                                        columnNumber: 57
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/_workflow/JobBoard.js",
                                lineNumber: 30,
                                columnNumber: 39
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].button,
                                onClick: ()=>setSearch(''),
                                children: "Clear search"
                            }, void 0, false, {
                                fileName: "[project]/app/_workflow/JobBoard.js",
                                lineNumber: 31,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/_workflow/JobBoard.js",
                        lineNumber: 30,
                        columnNumber: 7
                    }, this),
                    visibleJobs.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].empty,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                children: search ? 'No matching jobs' : completed ? 'No completed jobs yet' : 'No assigned jobs'
                            }, void 0, false, {
                                fileName: "[project]/app/_workflow/JobBoard.js",
                                lineNumber: 33,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: search ? 'Try a different search.' : completed ? 'Jobs you finish will appear here.' : 'Jobs will appear here when maintenance assigns them to you.'
                            }, void 0, false, {
                                fileName: "[project]/app/_workflow/JobBoard.js",
                                lineNumber: 34,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/_workflow/JobBoard.js",
                        lineNumber: 32,
                        columnNumber: 36
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].list,
                        children: visibleJobs.map((job)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].card,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$Shared$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ReportHeading"], {
                                        report: job,
                                        status: completed ? job.completed_status : job.status
                                    }, void 0, false, {
                                        fileName: "[project]/app/_workflow/JobBoard.js",
                                        lineNumber: 38,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$Shared$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ReportDetails"], {
                                        report: job
                                    }, void 0, false, {
                                        fileName: "[project]/app/_workflow/JobBoard.js",
                                        lineNumber: 39,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].details,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                        children: "Assigned"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/_workflow/JobBoard.js",
                                                        lineNumber: 41,
                                                        columnNumber: 18
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$display$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(job.assigned_at)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/_workflow/JobBoard.js",
                                                        lineNumber: 41,
                                                        columnNumber: 35
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/_workflow/JobBoard.js",
                                                lineNumber: 41,
                                                columnNumber: 13
                                            }, this),
                                            completed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                        children: "Completed"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/_workflow/JobBoard.js",
                                                        lineNumber: 42,
                                                        columnNumber: 32
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$display$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(job.completed_at)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/_workflow/JobBoard.js",
                                                        lineNumber: 42,
                                                        columnNumber: 50
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/_workflow/JobBoard.js",
                                                lineNumber: 42,
                                                columnNumber: 27
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/_workflow/JobBoard.js",
                                        lineNumber: 40,
                                        columnNumber: 11
                                    }, this),
                                    completed && job.status !== job.completed_status && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].muted,
                                        children: [
                                            "Current report status: ",
                                            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$display$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STATUS_LABELS"][job.status] || job.status
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/_workflow/JobBoard.js",
                                        lineNumber: 44,
                                        columnNumber: 64
                                    }, this),
                                    !completed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].primaryLink,
                                        href: notificationsLink,
                                        children: "Open job in notifications"
                                    }, void 0, false, {
                                        fileName: "[project]/app/_workflow/JobBoard.js",
                                        lineNumber: 45,
                                        columnNumber: 26
                                    }, this)
                                ]
                            }, job.job_id || job.id, true, {
                                fileName: "[project]/app/_workflow/JobBoard.js",
                                lineNumber: 37,
                                columnNumber: 35
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/_workflow/JobBoard.js",
                        lineNumber: 36,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/_workflow/JobBoard.js",
                lineNumber: 28,
                columnNumber: 14
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/_workflow/JobBoard.js",
        lineNumber: 18,
        columnNumber: 10
    }, this);
}
_s(JobBoard, "3kHjrYSsSsblVRPl8kgTxEEAZ6k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$useWorkflow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = JobBoard;
var _c;
__turbopack_context__.k.register(_c, "JobBoard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/_workflow/Shared.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LoadState",
    ()=>LoadState,
    "PageHeader",
    ()=>PageHeader,
    "ReportAttachment",
    ()=>ReportAttachment,
    "ReportDetails",
    ()=>ReportDetails,
    "ReportHeading",
    ()=>ReportHeading,
    "Status",
    ()=>Status
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$display$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/_workflow/display.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/app/_workflow/workflow.module.css [app-client] (css module)");
;
;
;
;
function PageHeader({ title, subtitle, role, refresh }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].eyebrow,
                        children: [
                            role,
                            " portal"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/_workflow/Shared.js",
                        lineNumber: 7,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/app/_workflow/Shared.js",
                        lineNumber: 7,
                        columnNumber: 57
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: subtitle
                    }, void 0, false, {
                        fileName: "[project]/app/_workflow/Shared.js",
                        lineNumber: 7,
                        columnNumber: 73
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/_workflow/Shared.js",
                lineNumber: 7,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].button,
                onClick: refresh,
                children: "Refresh"
            }, void 0, false, {
                fileName: "[project]/app/_workflow/Shared.js",
                lineNumber: 8,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/_workflow/Shared.js",
        lineNumber: 6,
        columnNumber: 10
    }, this);
}
_c = PageHeader;
function LoadState({ loading, error, signInRequired, refresh }) {
    if (loading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        role: "status",
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].empty,
        children: "Loading your information..."
    }, void 0, false, {
        fileName: "[project]/app/_workflow/Shared.js",
        lineNumber: 13,
        columnNumber: 23
    }, this);
    if (!error) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "alert",
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].error,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: error
            }, void 0, false, {
                fileName: "[project]/app/_workflow/Shared.js",
                lineNumber: 16,
                columnNumber: 5
            }, this),
            signInRequired ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].link,
                href: "/login/login",
                onClick: ()=>{
                    localStorage.removeItem('currentUser');
                    localStorage.removeItem('isLoggedIn');
                },
                children: "Sign in again"
            }, void 0, false, {
                fileName: "[project]/app/_workflow/Shared.js",
                lineNumber: 17,
                columnNumber: 23
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].button,
                onClick: refresh,
                children: "Try again"
            }, void 0, false, {
                fileName: "[project]/app/_workflow/Shared.js",
                lineNumber: 19,
                columnNumber: 31
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/_workflow/Shared.js",
        lineNumber: 15,
        columnNumber: 10
    }, this);
}
_c1 = LoadState;
function Status({ status }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badge} ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"][status] || ''}`,
        children: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$display$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STATUS_LABELS"][status] || status
    }, void 0, false, {
        fileName: "[project]/app/_workflow/Shared.js",
        lineNumber: 24,
        columnNumber: 10
    }, this);
}
_c2 = Status;
function ReportAttachment({ imagePath }) {
    const photo = typeof imagePath === 'string' && /^\/uploads\/[a-zA-Z0-9._-]+\.(png|jpe?g)$/i.test(imagePath);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].attachment,
        "aria-label": "Attached image",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                children: "Attached image"
            }, void 0, false, {
                fileName: "[project]/app/_workflow/Shared.js",
                lineNumber: 30,
                columnNumber: 5
            }, this),
            photo ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].link,
                href: imagePath,
                target: "_blank",
                rel: "noopener noreferrer",
                children: "View attached image"
            }, void 0, false, {
                fileName: "[project]/app/_workflow/Shared.js",
                lineNumber: 32,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].muted,
                children: "No attached image"
            }, void 0, false, {
                fileName: "[project]/app/_workflow/Shared.js",
                lineNumber: 33,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/_workflow/Shared.js",
        lineNumber: 29,
        columnNumber: 10
    }, this);
}
_c3 = ReportAttachment;
function ReportDetails({ report }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].description,
                children: report.description
            }, void 0, false, {
                fileName: "[project]/app/_workflow/Shared.js",
                lineNumber: 39,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].details,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                children: "Submitted"
                            }, void 0, false, {
                                fileName: "[project]/app/_workflow/Shared.js",
                                lineNumber: 41,
                                columnNumber: 12
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$display$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(report.created_at)
                            }, void 0, false, {
                                fileName: "[project]/app/_workflow/Shared.js",
                                lineNumber: 41,
                                columnNumber: 30
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/_workflow/Shared.js",
                        lineNumber: 41,
                        columnNumber: 7
                    }, this),
                    report.submitted_by && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                children: "Reported by"
                            }, void 0, false, {
                                fileName: "[project]/app/_workflow/Shared.js",
                                lineNumber: 42,
                                columnNumber: 36
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                children: report.submitted_by
                            }, void 0, false, {
                                fileName: "[project]/app/_workflow/Shared.js",
                                lineNumber: 42,
                                columnNumber: 56
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/_workflow/Shared.js",
                        lineNumber: 42,
                        columnNumber: 31
                    }, this),
                    report.technician_name && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                children: "Technician"
                            }, void 0, false, {
                                fileName: "[project]/app/_workflow/Shared.js",
                                lineNumber: 43,
                                columnNumber: 39
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                children: report.technician_name
                            }, void 0, false, {
                                fileName: "[project]/app/_workflow/Shared.js",
                                lineNumber: 43,
                                columnNumber: 58
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/_workflow/Shared.js",
                        lineNumber: 43,
                        columnNumber: 34
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/_workflow/Shared.js",
                lineNumber: 40,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ReportAttachment, {
                imagePath: report.image_path
            }, void 0, false, {
                fileName: "[project]/app/_workflow/Shared.js",
                lineNumber: 45,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/_workflow/Shared.js",
        lineNumber: 38,
        columnNumber: 10
    }, this);
}
_c4 = ReportDetails;
function ReportHeading({ report, status = report.status }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].cardHeading,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_workflow$2f$workflow$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reference,
                        children: [
                            "Report #",
                            report.id
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/_workflow/Shared.js",
                        lineNumber: 51,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        children: report.location
                    }, void 0, false, {
                        fileName: "[project]/app/_workflow/Shared.js",
                        lineNumber: 51,
                        columnNumber: 65
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/_workflow/Shared.js",
                lineNumber: 51,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Status, {
                status: status
            }, void 0, false, {
                fileName: "[project]/app/_workflow/Shared.js",
                lineNumber: 52,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/_workflow/Shared.js",
        lineNumber: 50,
        columnNumber: 10
    }, this);
}
_c5 = ReportHeading;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "PageHeader");
__turbopack_context__.k.register(_c1, "LoadState");
__turbopack_context__.k.register(_c2, "Status");
__turbopack_context__.k.register(_c3, "ReportAttachment");
__turbopack_context__.k.register(_c4, "ReportDetails");
__turbopack_context__.k.register(_c5, "ReportHeading");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/_workflow/display.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "STATUS_LABELS",
    ()=>STATUS_LABELS,
    "eventMessage",
    ()=>eventMessage,
    "filterReports",
    ()=>filterReports,
    "formatDate",
    ()=>formatDate
]);
const STATUS_LABELS = {
    open: 'Open',
    assigned: 'Assigned',
    in_progress: 'In Progress',
    resolved: 'Resolved',
    closed: 'Closed'
};
function formatDate(value) {
    if (!value) return 'Not recorded';
    // SQLite timestamps use UTC but do not include a timezone suffix.
    const text = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(value) ? value.replace(' ', 'T') + 'Z' : value;
    const date = new Date(text);
    if (Number.isNaN(date.getTime())) return 'Not recorded';
    return new Intl.DateTimeFormat('en-NZ', {
        dateStyle: 'medium',
        timeStyle: 'short'
    }).format(date);
}
function eventMessage(event) {
    if (event.kind === 'submitted') return 'Your fault report was submitted.';
    if (event.kind === 'assigned') return `${event.technician_name || 'A technician'} was assigned to your report.`;
    if (event.kind === 'unassigned') return 'The previous technician assignment was removed.';
    if (event.kind === 'snapshot') return `First recorded status: ${STATUS_LABELS[event.status] || event.status}.`;
    return `Report status changed to ${STATUS_LABELS[event.status] || event.status}.`;
}
function filterReports(reports, search, status = 'all') {
    const text = search.trim().toLowerCase();
    return reports.filter((report)=>{
        const matchesText = `${report.id} ${report.location} ${report.description}`.toLowerCase().includes(text);
        return matchesText && (status === 'all' || report.status === status);
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/_workflow/useWorkflow.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useWorkflow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
function useWorkflow(roleGroup) {
    _s();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [signInRequired, setSignInRequired] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const requestNumber = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const refresh = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useWorkflow.useCallback[refresh]": async ()=>{
            const number = ++requestNumber.current;
            try {
                const account = JSON.parse(localStorage.getItem('currentUser') || 'null');
                if (!account?.id) throw new Error('Please sign in to continue.');
                const response = await fetch('/api/workflow', {
                    cache: 'no-store',
                    headers: {
                        'x-workflow-user': String(account.id)
                    }
                });
                const result = await response.json();
                if (number !== requestNumber.current) return;
                setSignInRequired(response.status === 401);
                if (!response.ok) throw new Error(result.error || 'Unable to load your information.');
                const correctRole = roleGroup === 'technician' ? result.user.role === 'technician' : [
                    'student',
                    'staff'
                ].includes(result.user.role);
                if (!correctRole) throw new Error('This page is not available for your role.');
                setData(result);
                setError('');
            } catch (problem) {
                if (number === requestNumber.current) {
                    setData(null);
                    setError(problem.message || 'Unable to load your information. Please try again.');
                }
            } finally{
                if (number === requestNumber.current) setLoading(false);
            }
        }
    }["useWorkflow.useCallback[refresh]"], [
        roleGroup
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useWorkflow.useEffect": ()=>{
            refresh();
            const timer = setInterval({
                "useWorkflow.useEffect.timer": ()=>{
                    if (!document.hidden) refresh();
                }
            }["useWorkflow.useEffect.timer"], 15000);
            window.addEventListener('focus', refresh);
            return ({
                "useWorkflow.useEffect": ()=>{
                    ++requestNumber.current;
                    clearInterval(timer);
                    window.removeEventListener('focus', refresh);
                }
            })["useWorkflow.useEffect"];
        }
    }["useWorkflow.useEffect"], [
        refresh
    ]);
    return {
        data,
        error,
        loading,
        signInRequired,
        refresh
    };
}
_s(useWorkflow, "On8yyrUUOy0fTMNbSkfJKz7Jb0o=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/_workflow/workflow.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actions": "workflow-module__WlVD5a__actions",
  "assigned": "workflow-module__WlVD5a__assigned",
  "attachment": "workflow-module__WlVD5a__attachment",
  "badge": "workflow-module__WlVD5a__badge",
  "button": "workflow-module__WlVD5a__button",
  "card": "workflow-module__WlVD5a__card",
  "cardHeading": "workflow-module__WlVD5a__cardHeading",
  "checkbox": "workflow-module__WlVD5a__checkbox",
  "closed": "workflow-module__WlVD5a__closed",
  "description": "workflow-module__WlVD5a__description",
  "details": "workflow-module__WlVD5a__details",
  "empty": "workflow-module__WlVD5a__empty",
  "error": "workflow-module__WlVD5a__error",
  "eyebrow": "workflow-module__WlVD5a__eyebrow",
  "filters": "workflow-module__WlVD5a__filters",
  "header": "workflow-module__WlVD5a__header",
  "history": "workflow-module__WlVD5a__history",
  "in_progress": "workflow-module__WlVD5a__in_progress",
  "link": "workflow-module__WlVD5a__link",
  "list": "workflow-module__WlVD5a__list",
  "muted": "workflow-module__WlVD5a__muted",
  "notificationTools": "workflow-module__WlVD5a__notificationTools",
  "open": "workflow-module__WlVD5a__open",
  "page": "workflow-module__WlVD5a__page",
  "primaryLink": "workflow-module__WlVD5a__primaryLink",
  "progress": "workflow-module__WlVD5a__progress",
  "reference": "workflow-module__WlVD5a__reference",
  "resolved": "workflow-module__WlVD5a__resolved",
  "stats": "workflow-module__WlVD5a__stats",
  "tabs": "workflow-module__WlVD5a__tabs",
  "unread": "workflow-module__WlVD5a__unread",
});
}),
]);

//# sourceMappingURL=app__workflow_0ydhecx._.js.map