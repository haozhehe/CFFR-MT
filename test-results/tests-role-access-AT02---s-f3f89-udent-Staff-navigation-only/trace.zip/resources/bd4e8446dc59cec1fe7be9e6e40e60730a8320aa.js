(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0i_o_9x._.js","static/chunks/app_globals_0yg4wg8.css","static/chunks/app_AuthGuard_0auahlb.js","static/chunks/app__navigation_navigation_module_02li7cf.css","static/chunks/app__navigation_0jvspwg._.js","static/chunks/app_student_staff_dashboard_dashboard_module_0xq-qlu.css","static/chunks/app_student_staff_dashboard_06mqld9._.js"],
    source: "entry"
});
