(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/_navigation/PortalNavigation.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PortalNavigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_navigation$2f$navigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/app/_navigation/navigation.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function PortalNavigation({ role, children }) {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const [sidebar, setSidebar] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [userId, setUserId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const technician = role === 'technician';
    const dashboard = pathname === '/student_staff/dashboard';
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PortalNavigation.useEffect": ()=>{
            // Add the grouped menu to the existing sidebar without changing NavShell.js.
            setSidebar(document.querySelector('.app-shell > .sidebar'));
            try {
                const user = JSON.parse(localStorage.getItem('currentUser') || 'null');
                setUserId(user?.id || null);
            } catch  {
                setUserId(null);
            }
        }
    }["PortalNavigation.useEffect"], [
        pathname
    ]);
    const notificationsUrl = userId ? `/technician/notifications?userId=${encodeURIComponent(userId)}` : '/technician/notifications';
    const tabs = technician ? [
        {
            label: 'Notifications',
            href: notificationsUrl
        },
        {
            label: 'Assigned jobs',
            href: '/technician/assigned'
        },
        {
            label: 'Completed jobs',
            href: '/technician/completed'
        }
    ] : [
        {
            label: 'Fault report tracking',
            href: '/student_staff/my_reports'
        },
        {
            label: 'Notifications',
            href: '/student_staff/notifications'
        },
        {
            label: 'Submit a fault',
            href: '/student_staff/submit_fault'
        }
    ];
    const sections = technician ? [
        {
            label: 'Technician portal',
            href: '/technician/assigned',
            active: true
        }
    ] : [
        {
            label: 'Dashboard',
            href: '/student_staff/dashboard',
            active: dashboard
        },
        {
            label: 'Fault reports',
            href: '/student_staff/my_reports',
            active: !dashboard
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_navigation$2f$navigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].portal,
        children: [
            sidebar && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                className: `sidebar-nav ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_navigation$2f$navigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sidebarMenu}`,
                "aria-label": "Portal sections",
                children: sections.map((section)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: section.href,
                        "aria-current": section.active ? pathname === section.href ? 'page' : 'location' : undefined,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/app/_navigation/PortalNavigation.js",
                                lineNumber: 53,
                                columnNumber: 11
                            }, this),
                            section.label
                        ]
                    }, section.href, true, {
                        fileName: "[project]/app/_navigation/PortalNavigation.js",
                        lineNumber: 51,
                        columnNumber: 36
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/_navigation/PortalNavigation.js",
                lineNumber: 50,
                columnNumber: 7
            }, this), sidebar),
            !dashboard && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_navigation$2f$navigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].topSection,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_navigation$2f$navigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].tabs,
                    "aria-label": technician ? 'Technician portal pages' : 'Fault report pages',
                    children: tabs.map((tab)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: tab.href,
                            "aria-current": pathname === tab.href.split('?')[0] ? 'page' : undefined,
                            children: tab.label
                        }, tab.href, false, {
                            fileName: "[project]/app/_navigation/PortalNavigation.js",
                            lineNumber: 60,
                            columnNumber: 28
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/app/_navigation/PortalNavigation.js",
                    lineNumber: 59,
                    columnNumber: 7
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/_navigation/PortalNavigation.js",
                lineNumber: 58,
                columnNumber: 20
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$_navigation$2f$navigation$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content,
                children: children
            }, void 0, false, {
                fileName: "[project]/app/_navigation/PortalNavigation.js",
                lineNumber: 67,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/_navigation/PortalNavigation.js",
        lineNumber: 48,
        columnNumber: 10
    }, this);
}
_s(PortalNavigation, "6lz0cXCe3kalaGUXMxDoS5H8Zvc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = PortalNavigation;
var _c;
__turbopack_context__.k.register(_c, "PortalNavigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/_navigation/navigation.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "content": "navigation-module__Go6Pda__content",
  "portal": "navigation-module__Go6Pda__portal",
  "sidebarMenu": "navigation-module__Go6Pda__sidebarMenu",
  "tabs": "navigation-module__Go6Pda__tabs",
  "topSection": "navigation-module__Go6Pda__topSection",
});
}),
]);

//# sourceMappingURL=app__navigation_0jvspwg._.js.map