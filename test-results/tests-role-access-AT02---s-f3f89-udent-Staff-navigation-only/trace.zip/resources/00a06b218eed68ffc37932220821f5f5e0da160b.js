(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/AuthGuard.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AuthGuard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const ROLE_HOME = {
    student: '/student_staff/dashboard',
    staff: '/student_staff/dashboard',
    technician: '/technician/assigned',
    admin: '/admin_maintenance/admin_dashboard'
};
function AuthGuard({ children, allowedRoles = [] }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [accessAllowed, setAccessAllowed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [checkingAccess, setCheckingAccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthGuard.useEffect": ()=>{
            const loggedIn = window.localStorage.getItem('isLoggedIn') === 'true';
            const savedUser = window.localStorage.getItem('currentUser');
            if (!loggedIn || !savedUser) {
                setAccessAllowed(false);
                setCheckingAccess(false);
                router.replace('/login/login');
                return;
            }
            let currentUser;
            try {
                currentUser = JSON.parse(savedUser);
            } catch (error) {
                console.error('Unable to read current user:', error);
                window.localStorage.removeItem('isLoggedIn');
                window.localStorage.removeItem('currentUser');
                setAccessAllowed(false);
                setCheckingAccess(false);
                router.replace('/login/login');
                return;
            }
            const userRole = currentUser?.role;
            if (!userRole) {
                window.localStorage.removeItem('isLoggedIn');
                window.localStorage.removeItem('currentUser');
                setAccessAllowed(false);
                setCheckingAccess(false);
                router.replace('/login/login');
                return;
            }
            // check role access 
            if (allowedRoles.length > 0 && !allowedRoles.includes(userRole)) {
                setAccessAllowed(false);
                setCheckingAccess(false);
                const destination = ROLE_HOME[userRole] || '/login/login';
                router.replace(destination);
                return;
            }
            setAccessAllowed(true);
            setCheckingAccess(false);
        }
    }["AuthGuard.useEffect"], [
        allowedRoles,
        router
    ]);
    if (checkingAccess || !accessAllowed) {
        return null;
    }
    return children;
}
_s(AuthGuard, "JbQhWmgMLQzRwC3xBtffdon2YTE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = AuthGuard;
var _c;
__turbopack_context__.k.register(_c, "AuthGuard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_AuthGuard_0auahlb.js.map