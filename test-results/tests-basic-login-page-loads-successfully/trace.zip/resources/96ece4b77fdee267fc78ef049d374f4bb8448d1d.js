(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0i_o_9x._.js","static/chunks/app_globals_0yg4wg8.css","static/chunks/app_login_login_page_1gz7-8w.js"],
    source: "entry"
});
